import { Directive, ElementRef, Input, OnChanges, Renderer2, SimpleChanges } from '@angular/core';

@Directive({
  selector: '[appGradeColor]',
  standalone: true,
})
export class GradeColorDirective implements OnChanges {
  @Input('appGradeColor') score: number | null = null;

  constructor(private readonly el: ElementRef, private readonly renderer: Renderer2) {}

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['score']) {
      this.applyColor();
    }
  }

  private applyColor(): void {
    const score = this.score ?? 0;
    let color = '#c62828';

    if (score >= 90) {
      color = 'green';
    } else if (score >= 80) {
      color = 'blue';
    } else if (score >= 70) {
      color = 'goldenrod';
    } else if (score >= 60) {
      color = 'darkorange';
    }

    this.renderer.setStyle(this.el.nativeElement, 'color', color);
  }
}

