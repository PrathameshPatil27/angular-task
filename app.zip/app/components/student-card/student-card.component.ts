import { CommonModule, NgClass, NgStyle } from '@angular/common';
import { Component, EventEmitter, Input, OnChanges, Output, SimpleChanges } from '@angular/core';

import { GradeInput } from '../../models/grade.model';
import { Student } from '../../models/student.model';
import { GradeCalculatorService } from '../../services/grade-calculator.service';
import { GradeColorDirective } from '../../directives/grade-color.directive';
import { GpaCalculatorPipe } from '../../pipes/gpa-calculator.pipe';
import { LetterGradePipe } from '../../pipes/letter-grade.pipe';
import { GradeFormComponent } from '../grade-form/grade-form.component';

@Component({
  selector: 'app-student-card',
  standalone: true,
  imports: [
    CommonModule,
    NgClass,
    NgStyle,
    GradeFormComponent,
    GradeColorDirective,
    LetterGradePipe,
    GpaCalculatorPipe,
  ],
  templateUrl: './student-card.component.html',
  styleUrl: './student-card.component.css',
})
export class StudentCardComponent implements OnChanges {
  @Input() student!: Student;
  @Output() delete = new EventEmitter<string>();
  @Output() addGrade = new EventEmitter<{ studentId: string; grade: GradeInput }>();

  average = 0;
  letter = 'F';

  constructor(private readonly gradeCalculator: GradeCalculatorService) {}

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['student']) {
      this.recalculate();
    }
  }

  onDelete() {
    this.delete.emit(this.student.id);
  }

  onAddGrade(grade: GradeInput) {
    this.addGrade.emit({ studentId: this.student.id, grade });
  }

  get performanceClass(): string {
    if (this.average >= 90) return 'excellent';
    if (this.average >= 80) return 'good';
    if (this.average >= 70) return 'average';
    return 'poor';
  }

  get performanceBarWidth(): string {
    return `${this.average}%`;
  }

  private recalculate(): void {
    this.average = this.gradeCalculator.calculateAverage(this.student.grades);
    this.letter = this.gradeCalculator.getLetterGrade(this.average);
  }

  trackGrade(index: number, grade: { subject: string; date: Date }): string {
    return `${grade.subject}-${grade.date}`;
  }
}

