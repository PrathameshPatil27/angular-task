import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Output } from '@angular/core';
import { FormsModule, NgForm } from '@angular/forms';

import { StudentCreateInput } from '../../models/student.model';

@Component({
  selector: 'app-add-student',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './add-student.component.html',
  styleUrl: './add-student.component.css',
})
export class AddStudentComponent {
  @Output() create = new EventEmitter<StudentCreateInput>();

  name = '';
  email = '';
  enrollmentDate: string = '';

  submitting = false;

  onSubmit(form: NgForm) {
    if (!this.name.trim() || !this.email.trim() || !this.enrollmentDate) {
      return;
    }

    this.submitting = true;

    const payload: StudentCreateInput = {
      name: this.name.trim(),
      email: this.email.trim(),
      enrollmentDate: new Date(this.enrollmentDate),
    };

    this.create.emit(payload);

    form.reset();
    this.submitting = false;
  }
}

