import { CommonModule } from '@angular/common';
import { Component, Input, OnChanges, SimpleChanges } from '@angular/core';

import { Student } from '../../models/student.model';
import { GradeCalculatorService } from '../../services/grade-calculator.service';

@Component({
  selector: 'app-stats',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './stats.component.html',
  styleUrl: './stats.component.css',
})
export class StatsComponent implements OnChanges {
  @Input() students: Student[] | null = [];

  totalStudents = 0;
  classAverage = 0;
  highestStudent?: Student;
  lowestStudent?: Student;

  constructor(private readonly gradeCalculator: GradeCalculatorService) {}

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['students']) {
      this.recalculate();
    }
  }

  private recalculate(): void {
    const list = this.students ?? [];
    this.totalStudents = list.length;

    if (list.length === 0) {
      this.classAverage = 0;
      this.highestStudent = undefined;
      this.lowestStudent = undefined;
      return;
    }

    const withAverages = list.map((s) => ({
      student: s,
      average: this.gradeCalculator.calculateAverage(s.grades),
    }));

    const total = withAverages.reduce((sum, x) => sum + x.average, 0);
    this.classAverage = total / withAverages.length;

    this.highestStudent = withAverages.reduce((best, current) =>
      !best || current.average > best.average ? current : best,
    ).student;

    this.lowestStudent = withAverages.reduce((worst, current) =>
      !worst || current.average < worst.average ? current : worst,
    ).student;
  }
}

