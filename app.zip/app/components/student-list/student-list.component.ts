import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, Output } from '@angular/core';

import { Student } from '../../models/student.model';
import { StudentCardComponent } from '../student-card/student-card.component';

@Component({
  selector: 'app-student-list',
  standalone: true,
  imports: [CommonModule, StudentCardComponent],
  templateUrl: './student-list.component.html',
  styleUrl: './student-list.component.css',
})
export class StudentListComponent {
  @Input() students: Student[] | null = [];
  @Output() deleteStudent = new EventEmitter<string>();
  @Output() addGrade = new EventEmitter<{ studentId: string; grade: any }>();

  trackStudent(_index: number, student: Student): string {
    return student.id;
  }

  onDeleteStudent(id: string) {
    this.deleteStudent.emit(id);
  }

  onAddGrade(event: { studentId: string; grade: any }) {
    this.addGrade.emit(event);
  }
}

