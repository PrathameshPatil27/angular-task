import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, Output, SimpleChanges, OnChanges } from '@angular/core';
import { FormsModule, NgForm } from '@angular/forms';

import { GradeInput } from '../../models/grade.model';

@Component({
  selector: 'app-grade-form',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './grade-form.component.html',
  styleUrl: './grade-form.component.css',
})
export class GradeFormComponent implements OnChanges {
  @Input() disabled = false;
  @Output() addGrade = new EventEmitter<GradeInput>();

  subject = '';
  score: number | null = null;

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['disabled'] && this.disabled) {
      this.reset();
    }
  }

  onSubmit(form: NgForm) {
    if (!this.subject.trim() || this.score == null) {
      return;
    }

    const payload: GradeInput = {
      subject: this.subject.trim(),
      score: this.score,
      date: new Date(),
    };

    this.addGrade.emit(payload);
    this.reset();
    form.reset();
  }

  private reset(): void {
    this.subject = '';
    this.score = null;
  }
}

