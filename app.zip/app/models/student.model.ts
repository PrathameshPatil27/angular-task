import { Grade } from './grade.model';

export interface Student {
  id: string;
  name: string;
  email: string;
  enrollmentDate: Date;
  grades: Grade[];
}

export interface StudentCreateInput {
  name: string;
  email: string;
  enrollmentDate: Date;
}

