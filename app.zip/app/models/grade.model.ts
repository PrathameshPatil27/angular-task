export interface Grade {
  subject: string;
  score: number;
  date: Date;
}

export interface GradeInput {
  subject: string;
  score: number;
  date?: Date;
}

