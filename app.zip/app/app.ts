import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Observable } from 'rxjs';

import { AddStudentComponent } from './components/add-student/add-student.component';
import { StatsComponent } from './components/stats/stats.component';
import { StudentListComponent } from './components/student-list/student-list.component';
import {
  FilterByPerformancePipe,
  PerformanceFilter,
} from './pipes/filter-by-performance.pipe';
import { GradeInput } from './models/grade.model';
import { Student, StudentCreateInput } from './models/student.model';
import { StudentService } from './services/student.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.html',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    AddStudentComponent,
    StudentListComponent,
    StatsComponent,
    FilterByPerformancePipe,
  ],
  styleUrl: './app.css',
})
export class AppComponent {
  title = 'Student Grade Tracker';
  performanceFilter: PerformanceFilter = 'All';

  constructor(private readonly studentService: StudentService) {}

  get students$(): Observable<Student[]> {
    return this.studentService.getStudents();
  }

  onStudentCreated(input: StudentCreateInput) {
    this.studentService.addStudent(input);
  }

  onDeleteStudent(studentId: string) {
    this.studentService.deleteStudent(studentId);
  }

  onAddGrade(event: { studentId: string; grade: GradeInput }) {
    this.studentService.addGrade(event.studentId, event.grade);
  }
}

// Alias to keep existing AppModule/app.spec.ts working without signals.
export { AppComponent as App };