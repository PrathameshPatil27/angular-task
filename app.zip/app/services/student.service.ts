import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

import { Grade, GradeInput } from '../models/grade.model';
import { Student, StudentCreateInput } from '../models/student.model';
import { GradeCalculatorService } from './grade-calculator.service';

@Injectable({
  providedIn: 'root',
})
export class StudentService {
  private readonly studentsSubject = new BehaviorSubject<Student[]>([]);

  constructor(private readonly gradeCalculator: GradeCalculatorService) {}

  getStudents(): Observable<Student[]> {
    return this.studentsSubject.asObservable();
  }

  addStudent(input: StudentCreateInput): void {
    const current = this.studentsSubject.getValue();
    const newStudent: Student = {
      id: crypto.randomUUID ? crypto.randomUUID() : Date.now().toString(),
      name: input.name.trim(),
      email: input.email.trim(),
      enrollmentDate: input.enrollmentDate,
      grades: [],
    };

    this.studentsSubject.next([...current, newStudent]);
  }

  deleteStudent(id: string): void {
    const updated = this.studentsSubject.getValue().filter((s) => s.id !== id);
    this.studentsSubject.next(updated);
  }

  addGrade(studentId: string, gradeInput: GradeInput): void {
    const students = this.studentsSubject.getValue();
    const updated = students.map((student) => {
      if (student.id !== studentId) {
        return student;
      }

      const grade: Grade = {
        subject: gradeInput.subject.trim(),
        score: gradeInput.score,
        date: gradeInput.date ?? new Date(),
      };

      return {
        ...student,
        grades: [...student.grades, grade],
      };
    });

    this.studentsSubject.next(updated);
  }

  calculateAverageForStudent(student: Student): number {
    return this.gradeCalculator.calculateAverage(student.grades);
  }

  getLetterGradeForStudent(student: Student): string {
    const avg = this.calculateAverageForStudent(student);
    return this.gradeCalculator.getLetterGrade(avg);
  }
}

