import { Injectable } from '@angular/core';

import { Grade } from '../models/grade.model';

@Injectable({
  providedIn: 'root',
})
export class GradeCalculatorService {
  calculateAverage(grades: Grade[]): number {
    if (!grades || grades.length === 0) {
      return 0;
    }

    const total = grades.reduce((sum, grade) => sum + grade.score, 0);
    return total / grades.length;
  }

  getLetterGrade(score: number): string {
    if (score >= 90) return 'A';
    if (score >= 80) return 'B';
    if (score >= 70) return 'C';
    if (score >= 60) return 'D';
    return 'F';
  }

  getGpaFromGrades(grades: Grade[]): number {
    if (!grades || grades.length === 0) {
      return 0;
    }

    const totalPoints = grades.reduce((sum, grade) => sum + this.toGpaPoints(grade.score), 0);
    return totalPoints / grades.length;
  }

  private toGpaPoints(score: number): number {
    if (score >= 90) return 4.0;
    if (score >= 80) return 3.0;
    if (score >= 70) return 2.0;
    if (score >= 60) return 1.0;
    return 0;
  }
}

