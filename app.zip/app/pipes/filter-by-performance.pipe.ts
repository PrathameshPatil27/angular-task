import { Pipe, PipeTransform } from '@angular/core';

import { Student } from '../models/student.model';
import { GradeCalculatorService } from '../services/grade-calculator.service';

export type PerformanceFilter = 'All' | 'Excellent' | 'Good' | 'Average' | 'Poor';

@Pipe({
  name: 'filterByPerformance',
  standalone: true,
  pure: true,
})
export class FilterByPerformancePipe implements PipeTransform {
  constructor(private readonly gradeCalculator: GradeCalculatorService) {}

  transform(students: Student[] | null, filter: PerformanceFilter): Student[] {
    if (!students || filter === 'All') {
      return students ?? [];
    }

    return students.filter((student) => {
      const avg = this.gradeCalculator.calculateAverage(student.grades);

      switch (filter) {
        case 'Excellent':
          return avg >= 90;
        case 'Good':
          return avg >= 80 && avg < 90;
        case 'Average':
          return avg >= 70 && avg < 80;
        case 'Poor':
          return avg < 70;
      }
    });
  }
}

