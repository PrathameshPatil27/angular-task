import { Pipe, PipeTransform } from '@angular/core';

import { Grade } from '../models/grade.model';
import { GradeCalculatorService } from '../services/grade-calculator.service';

@Pipe({
  name: 'gpaCalculator',
  standalone: true,
})
export class GpaCalculatorPipe implements PipeTransform {
  constructor(private readonly gradeCalculator: GradeCalculatorService) {}

  transform(grades: Grade[] | null | undefined): number {
    if (!grades) {
      return 0;
    }

    return this.gradeCalculator.getGpaFromGrades(grades);
  }
}

