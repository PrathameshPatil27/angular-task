import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'letterGrade',
  standalone: true,
})
export class LetterGradePipe implements PipeTransform {
  transform(score: number | null | undefined): string {
    const value = score ?? 0;

    if (value >= 90) return 'A';
    if (value >= 80) return 'B';
    if (value >= 70) return 'C';
    if (value >= 60) return 'D';
    return 'F';
  }
}

