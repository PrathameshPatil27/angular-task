import express from 'express'
import cookieParser from "cookie-parser"
import cors from "cors"
import { Request,Response } from "express"
import authRoutes from "./routes/auth.routes"
import adminRoutes from "./routes/admin.routes"
import productRoutes from "./routes/product.routes"
import cartRoutes from "./routes/cart.routes"
import orderRoutes from "./routes/order.routes"
import { AppDataSource } from './data-source'
import { User } from './entities/User'
import path from 'node:path'
import { globalErrorHandler } from './middleware/error.middleware'
const app=express()
app.use(express.json());
app.use(express.urlencoded({extended:true}));
app.use(cookieParser());
app.use(cors({
    origin:['http://localhost:4200', 'http://localhost:3000'],
    credentials:true
}))
app.use("/uploads", express.static("uploads"));
app.use("/api/auth",authRoutes)
app.use("/api/admin",adminRoutes)
app.use("/api/products",productRoutes)
app.use("/api/cart",cartRoutes)
app.use("/api/orders",orderRoutes)
app.get("/api/make-admin/:email",
    async(req,res)=>{
        const repo=AppDataSource.getRepository(User);
        const user=await repo.findOneBy({email:req.params.email})
        if(user)
        {
            user.role="admin";
            await repo.save(user);
            return res.send(`${user.email} is now an admin`)
        }
        res.status(404).send("user not found")
    }
)
app.get('/api/health',(req:Request,res:Response)=>{
    res.json({status:"API is running",
        databse:"TypeORM Connected"
    })
})
const publicPath = path.join(__dirname, 'public')
app.use(express.static(publicPath))
app.get('/*splat', (req, res) => {
    res.sendFile(path.join(publicPath, 'index.html'))
})
app.use(globalErrorHandler)
export default app;