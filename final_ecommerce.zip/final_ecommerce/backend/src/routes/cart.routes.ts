import { Router } from "express";
import { requireAuth } from "../middleware/auth.middleware";
import * as cartCtrl from "../controllers/cart.controller"
const router=Router();
router.use(requireAuth)
router.post("/add",cartCtrl.addToCart)
router.get("/",cartCtrl.getMyCart)
router.delete("/remove/:itemId",cartCtrl.removeFromCart)
export default router;