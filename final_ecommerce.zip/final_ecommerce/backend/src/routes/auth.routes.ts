import { Router } from "express";
import { AuthSchemas, validate } from "../middleware/auth.middleware";
import * as AuthCtrl from "../controllers/auth.controller"

const router=Router();

router.post('/register',validate(AuthSchemas.register),AuthCtrl.register)
router.post('/login',validate(AuthSchemas.login),AuthCtrl.login);
router.post('/logout',AuthCtrl.logout);
router.post('/forgot-password',AuthCtrl.forgotPassword)
router.post('/reset-password',validate(AuthSchemas.reset),AuthCtrl.resetPassword)
router.get('/me',AuthCtrl.getMe)
router.get('/user-profile',AuthCtrl.getUserProfile)
router.put("/update-profile",AuthCtrl.updateProfile)
export default router