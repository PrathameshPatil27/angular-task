import { Router } from "express";
import { requireAuth } from "../middleware/auth.middleware";
import * as orderCtrl from "../controllers/order.controller"
const router=Router();
router.use(requireAuth);
router.post("/checkout",orderCtrl.checkout)
router.get("/history",orderCtrl.getOrderHistory)
router.get("/:id",orderCtrl.getOrderDetails)
export default router;