import { Router } from "express";
import * as productCtrl from "../controllers/product.controller"
import { requireAdmin, requireAuth } from "../middleware/auth.middleware";
import { upload } from "../config/multerConfig";
const router=Router();
router.get("/",productCtrl.getAllProducts);
router.get("/:id",productCtrl.getProductById);

// admin only routes
router.post("/",requireAuth,requireAdmin,upload.single("image"),productCtrl.createProduct);
router.put("/:id",requireAuth,requireAdmin,upload.single("image"),productCtrl.updateProduct);
router.delete("/:id",requireAuth,requireAdmin,productCtrl.deleteProduct);
export default router;