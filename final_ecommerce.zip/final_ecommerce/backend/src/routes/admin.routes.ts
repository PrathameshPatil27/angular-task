import { Router } from "express";
import * as AdminCtrl from "../controllers/admin.controller"
import { requireAuth,requireAdmin } from "../middleware/auth.middleware";
const router=Router();
router.get("/types",AdminCtrl.getTypes);
router.get('/categories',AdminCtrl.getCategories);
router.get("/sub-categories",AdminCtrl.getSubCategories)
router.get("/getAllSalesData",AdminCtrl.getAllSalesData)
router.post("/types",requireAuth,requireAdmin,AdminCtrl.createType)
router.post("/categories",requireAuth,requireAdmin,AdminCtrl.createCategory)
router.post("/sub-categories",requireAuth,requireAdmin,AdminCtrl.createSubCategory)
router.get("/users",AdminCtrl.getAllUsers)
router.patch("/users/:userId",requireAuth,AdminCtrl.toggleCustomerLock)
export default router;