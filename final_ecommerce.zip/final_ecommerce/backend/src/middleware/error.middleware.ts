import { NextFunction, Request, Response } from "express";
import { error } from "node:console";
import { success } from "zod";

export const globalErrorHandler=(err:any,req:Request,res:Response,next:NextFunction)=>
{
    const statusCode=err.statusCode||500;
    const message=err.message||"Internal Server error"
    console.error(`[Error] ${req.method} ${req.url}:`,err.message);
    res.status(statusCode).json({
        message:message
    })
}