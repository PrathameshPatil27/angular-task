import dotenv from "dotenv"
dotenv.config();
import express from "express"

import { AppDataSource } from "./data-source"
import app from "./app"


const PORT=process.env.PORT||3000;

// app.use(express.json());
// app.use(express.urlencoded({extended:true}));
// app.use(cookieParser());
// app.use(cors({
//     origin:'http://localhost:4200',
//     credentials:true
// }))
// app.get('/api/health',(req:Request,res:Response)=>{
//     res.json({status:"API is running",
//         databse:"TypeORM Connected"
//     })
// })

AppDataSource.initialize().then(()=>{
    console.log("Connected to the SQLite databse via TypeORM");
    app.listen(PORT,()=>{
        console.log(`Server is running on http://localhost:${PORT}`)
    })
})
.catch((error)=>{
    console.log("Database connection error:",error)
})