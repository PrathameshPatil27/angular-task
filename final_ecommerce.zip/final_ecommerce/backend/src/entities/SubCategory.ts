import { Column, Entity, ManyToOne, OneToMany, PrimaryGeneratedColumn } from "typeorm";
import { Category } from "./Category";
import { Product } from "./Product";


@Entity("sub_categories")
export class SubCategory{
    @PrimaryGeneratedColumn("uuid")
    id!:string;

    @Column({type:"varchar"})
    name!:string;

    @ManyToOne(()=>Category,(category)=>category.sub_categories,{nullable:false,onDelete:"CASCADE"})
    category!:Category;

    @OneToMany(()=>Product,(product)=>product.sub_category)
    products!:Product[];
}