import { Column, CreateDateColumn, Entity, ManyToOne, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";
import { int } from "zod";
import { SubCategory } from "./SubCategory";

@Entity("products")
export class Product{
    @PrimaryGeneratedColumn("uuid")
    id!:string;

    @Column({type:"varchar"})
    name!:string;

    @Column({type:"text"})
    description!:string;

    @Column({type:"decimal" ,precision:10,scale:2})
    price!:number;

    @Column({type:"varchar",nullable:true})
    image_url!:string;

    @Column({type:"int",default:0})
    stock!:number
    
    @ManyToOne(()=>SubCategory,(subCategory)=>subCategory.products,{nullable:false,onDelete:"RESTRICT"})
    sub_category!:SubCategory;

    @CreateDateColumn()
    created_at!:Date;

    @UpdateDateColumn()
    updated_at!:Date;
}