import { Column, Entity, OneToMany, PrimaryGeneratedColumn } from "typeorm";
import { Category } from "./Category";

@Entity("types")
export class Type{
    @PrimaryGeneratedColumn("uuid")
    id!:string;

    @Column({type:"varchar",unique:true})
    name!:string;

    @OneToMany(()=>Category,(category)=>category.type)
    categories!:Category[];
}