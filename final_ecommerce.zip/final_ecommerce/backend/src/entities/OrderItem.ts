import { Column, Entity, JoinColumn, ManyToOne, PrimaryGeneratedColumn } from "typeorm";
import { Order } from "./Order";
import { Product } from "./Product";

@Entity("order_items")
export class OrderItem{
    @PrimaryGeneratedColumn("uuid")
    id!:string;

    @Column({type:"int"})
    quantity!:number;

    @Column({type:"int"})
    price_at_purchase!:number;

    @ManyToOne(()=>Order,(order)=>order.items,{nullable:false,onDelete:"CASCADE"})
    order!:Order;

    @ManyToOne(()=>Product,{nullable:false,onDelete:"RESTRICT"})
    product!:Product;
}