import { Column, CreateDateColumn, Entity, ManyToOne, OneToMany, PrimaryGeneratedColumn } from "typeorm";
import { User } from "./User";
import { OrderItem } from "./OrderItem";

@Entity("orders")
export class Order{
    @PrimaryGeneratedColumn("uuid")
    id!:string;

    @Column({type:"int"})
    total_amount!:number;

    @Column({type:"varchar",default:"pending"})
    status!:string;

    @Column({type:"varchar",nullable:true})
    payment_method!:string;

    @ManyToOne(()=>User,{nullable:false,onDelete:"RESTRICT"})
    user!:User;

    @OneToMany(()=>OrderItem,(orderItem)=>orderItem.order,{cascade:true})
    items!:OrderItem[];

    @CreateDateColumn()
    created_at!:Date;

}