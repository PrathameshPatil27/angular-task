import { Column, CreateDateColumn, Entity, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";

@Entity('user')
export class User {
    @PrimaryGeneratedColumn("uuid")
    id!: string;

    @Column({ type: "varchar", unique: true })
    email!: string;

    @Column({ type: "varchar", nullable: true })
    username!: string;

    @Column({ type: "varchar" })
    password_hash!: string;

    @Column({ type: "varchar", default: "customer" })
    role!: string;

    @Column({ type: "boolean", default: false })
    is_locked!: boolean;

    @Column({ type: "varchar", nullable: true })
    address!: string | null;

    @Column({ type: "varchar", nullable: true })
    reset_password_token!: string | null;

    @Column({ type: "datetime", nullable: true })
    reset_password_expires!: Date | null;

    @CreateDateColumn()
    created_at!: Date;

    @UpdateDateColumn()
    updated_at!: Date;
}