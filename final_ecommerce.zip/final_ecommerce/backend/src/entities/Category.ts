import { Column, Entity, ManyToOne, OneToMany, PrimaryGeneratedColumn } from "typeorm";
import { Type } from "./Type";
import { SubCategory } from "./SubCategory";

@Entity("categories")
export class Category{
    @PrimaryGeneratedColumn("uuid")
    id!:string;

    @Column({type:"varchar"})
    name!:string;

    @ManyToOne(()=>Type,(type)=>type.categories,{nullable:false,onDelete:"CASCADE"})
    type!:Type;

    @OneToMany(()=>SubCategory,(subCategory)=>subCategory.category)
    sub_categories!:SubCategory[];
}