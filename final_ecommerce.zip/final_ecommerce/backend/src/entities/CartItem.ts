import { Column, Entity, ManyToOne, PrimaryGeneratedColumn } from "typeorm";
import { string } from "zod";
import { User } from "./User";
import { Product } from "./Product";

@Entity("cart_items")
export class CartItem{
    @PrimaryGeneratedColumn("uuid") 
    id!:string;

    @Column({type:"int",default:1})
    quantity!:number;

    @ManyToOne(()=>User,{nullable:false,onDelete:"CASCADE"})
    user!:User;

    @ManyToOne(()=>Product,{nullable:false,onDelete:"CASCADE"})
    product!:Product;

}