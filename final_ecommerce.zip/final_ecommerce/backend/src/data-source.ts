import "reflect-metadata";
import {DataSource} from "typeorm"
import { User } from "./entities/User";
import { Type } from "./entities/Type";
import { Category } from "./entities/Category";
import { SubCategory } from "./entities/SubCategory";
import { Product } from "./entities/Product";
import { CartItem } from "./entities/CartItem";
import { Order } from "./entities/Order";
import { OrderItem } from "./entities/OrderItem";
export const AppDataSource=new DataSource({
    type:"better-sqlite3",
    database:"ecommerce.db",
    synchronize:false,
    logging:false,
    entities:[User,Type,Category,SubCategory,Product,CartItem,Order,OrderItem],
    subscribers:[],
    migrations:["src/migrations/*.ts"]
})