import { NextFunction, Request, Response } from "express";
import { AppDataSource } from "../data-source";
import { Category } from "../entities/Category";
import { Type } from "../entities/Type";
import { SubCategory } from "../entities/SubCategory";
import { Product } from "../entities/Product";
import { OrderItem } from "../entities/OrderItem";
import { User } from "../entities/User";
import { error } from "node:console";
import { sessionStore } from "../store/sessionStore";
const typeRepo = AppDataSource.getRepository(Type);
const categoryRepo = AppDataSource.getRepository(Category)
const SubCategoryRepo = AppDataSource.getRepository(SubCategory)
const productRepo=AppDataSource.getRepository(Product);
const orderItemRepo=AppDataSource.getRepository(OrderItem)
const userRepo=AppDataSource.getRepository(User)
export const createType = async (req: Request, res: Response) => {
    const { name } = req.body;
    const type = typeRepo.create({ name });
    await typeRepo.save(type);
    res.status(201).json(type)
}
export const getTypes= async (req: Request, res: Response) => {
    const types = await typeRepo.find();
    res.json(types);
}
export const createCategory = async (req: Request, res: Response) => {
    const { name, typeId } = req.body;
    const type = await typeRepo.findOneBy({ id: typeId });
    if (!type) {
        return res.status(404).json({ error: "Type not found" })
    }
    const category = categoryRepo.create({ name, type });
    await categoryRepo.save(category);
    res.status(201).json(category)
}
export const getCategories=async (req:Request,res:Response)=>{
    const categories=await categoryRepo.find({relations:['type']})
    res.json(categories)
}
export const createSubCategory = async (req: Request, res: Response,next:NextFunction) => {
    try {
        const { name, categoryId } = req.body;
        const category = await categoryRepo.findOneBy({ id: categoryId })
        if (!category) {
            return res.status(404).json({ error: "Parent category not found" });
        }
        const SubCategory = SubCategoryRepo.create({ name, category });
        await SubCategoryRepo.save(SubCategory);
        res.status(201).json(SubCategory)
    }
    catch(e)
    {
        next(e)
    }
}
export const getSubCategories=async(req:Request,res:Response)=>{
    const subCategories=await SubCategoryRepo.find({relations:['category']})
    res.json(subCategories)

}
export const getAllSalesData=async(req:Request,res:Response,next:NextFunction)=>{
    try
    {
        const sales=await orderItemRepo.find({
            relations:{
                product:true,
                order:{
                    user:true
                }
            },
            order:{
                order:{
                    created_at:'DESC'
                }
            }
        });
        console.log(sales[0])
        res.status(200).json(sales)
    }
    catch(error:any)
    {
        next(error)
    }
}
export const toggleCustomerLock = async (req: Request, res: Response,next:NextFunction) => {
    try {
        
        const userId = req.params.userId as string; 
        const loggedInAdminId=(req as any).user.id;
        const user = await userRepo.findOneBy({ id: userId });
        if(userId==loggedInAdminId)
        {
            res.status(400).json({error:"You can not lock your own account"})
        }
        if (!user) {
            return res.status(404).json({ error: "User not found" });
        }
        user.is_locked = !user.is_locked;
        await userRepo.save(user);
        if(user.is_locked)
        {
            console.log("Attempting to kick user",userId)
            let sessionFound=false
            for(const[token,sessionData] of sessionStore.entries())
            {
                console.log("checking session for ",sessionData.id)
                if(String(sessionData.id)===String(userId))
                {
                    sessionStore.delete(token)
                    sessionFound=true
                    console.log(`session for ${userId} is destroyed`)
                }
            }
            if(!sessionFound)
            {
                console.log("No active session foer this user")
            }
        }
        return res.json({
            message: `User ${user.is_locked ? 'locked' : 'unlocked'} successfully`,
            is_locked: user.is_locked
        });

    } catch (error: any) {
       next(error)
    }
};
export const getAllUsers = async (req: Request, res: Response,next:NextFunction) => {
    try {
        const users = await userRepo.find({
            select: {
                id: true,
                username: true,
                email: true,
                is_locked: true,
            },
            order: {
                username: "ASC"
            }
        });

        return res.json(users);
    } catch (error: any) {
        next(error)
    }
};