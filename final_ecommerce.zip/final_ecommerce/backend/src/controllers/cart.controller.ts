import { AppDataSource } from "../data-source";
import { Order } from "../entities/Order";
import { OrderItem } from "../entities/OrderItem";
import { Product } from "../entities/Product";
import { NextFunction, Request, Response } from "express"
const orderRepo = AppDataSource.getRepository(Order);
const itemRepo = AppDataSource.getRepository(OrderItem);
const productRepo = AppDataSource.getRepository(Product);
export const addToCart = async (req: Request, res: Response,next:NextFunction) => {
    try {
        const { productId, quantity } = req.body;
        const user = (req as any).user;
        if(!user){
            return res.status(401).json({error:"user not found"})
        }
        let order = await orderRepo.findOne({
            where: {
                user: {id:user.id},
                status: "pending"
            }
        })
        if (!order) {
            order = orderRepo.create({
                user: {id:user.id},
                status: "pending",
                total_amount: 0,
                payment_method:"pending"
            })
            order=await orderRepo.save(order)
        }
        const product = await productRepo.findOneBy({ id: productId })
        if (!product) {
            return res.status(404).json({ error: "Product not found" })
        }

        let item = await itemRepo.findOne({
            where: {
                order: { id: order.id },
                product: { id: productId }
            }
        })
        if (item) {
            item.quantity += Number(quantity)
            if(item.quantity<=0)
            {
                await itemRepo.remove(item);
                return res.status(200).json({message:"Item removed from cart"})
            }
        }
        else {
            item = itemRepo.create({
                order:order,
                product:product,
                quantity: Number(quantity),
                price_at_purchase: product.price
            })
        }
        await itemRepo.save(item);
        res.status(200).json({ message: "Item added to cart" })
    }
    catch (error: any) {
        next(error)
    }
}
export const getMyCart = async (req: Request, res: Response,next:NextFunction) => {
    try {
        const user = (req as any).user;
        const cart = await orderRepo.findOne({
            where: {
                user: { id: user.id },
                status: "pending"
            },
            
            relations:{
                items:{
                    product:true
                }
            }
        })
        console.log("cart found:",cart?.id)
        console.log("Item count",cart?.items?.length)
        res.json(cart||{items:[]})
    }
    catch (error: any) {
        next(error)
    }
}
export const removeFromCart=async(req:Request,res:Response,next:NextFunction)=>{
    try{
        const {itemId}=req.params;
        const user=(req as any).user;
        const item=await itemRepo.findOne({
            where:{
                id:itemId as string,
                order:{user:{id:user.id},status:"pending"}
            }
        })
        if(!item)
        {
            return res.status(404).json({error:"Item not found in cart"})
        }
        await itemRepo.remove(item);
        res.status(200).json({message:"Item removed from cart"})
    }
    catch(error:any){
        next(error)
        
    }
    
}