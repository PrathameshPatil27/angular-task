import { NextFunction, Request, Response } from "express";
import { AppDataSource } from "../data-source";
import { Product } from "../entities/Product";
import { SubCategory } from "../entities/SubCategory";
import { Between, Like, } from "typeorm";
import { error } from "node:console";
const productRepo=AppDataSource.getRepository(Product);
const subCategoryRepo=AppDataSource.getRepository(SubCategory)

export const getAllProducts = async (req: Request, res: Response,next:NextFunction) => {
  try {
    const { search, minPrice, maxPrice, subCategoryId, categoryId, typeId, page = "1", limit = "10" } = req.query;

    const pageNumber = Number(page);
    const pageSize = Number(limit);

    let queryOptions: any = {
      relations: ["sub_category", "sub_category.category", "sub_category.category.type"],
      where: {},
      skip: (pageNumber - 1) * pageSize,
      take: pageSize,
    };

    if (search) {
      queryOptions.where.name = Like(`%${search}%`);
    }

    if (subCategoryId) {
      queryOptions.where.sub_category = { id: subCategoryId };
    } else if (categoryId) {
      queryOptions.where.sub_category = { category: { id: categoryId } };
    } else if (typeId) {
      queryOptions.where.sub_category = { category: { type: { id: typeId } } };
    }

    if (minPrice !== undefined && maxPrice !== undefined) {
      const min = Number(minPrice);
      const max = Number(maxPrice);

      if (!isNaN(min) && !isNaN(max)) {
        queryOptions.where.price = Between(min, max);
      }
    }

    const [products, total] = await productRepo.findAndCount(queryOptions);
    console.log("DB products:", products.length, products);


    res.status(200).json({
      data: products,
      pagination: {
        total,
        page: pageNumber,
        limit: pageSize,
        totalPages: Math.ceil(total / pageSize),
      },
    });
  } catch (error: any) {
    next(error)
  }
};
export const getProductById=async (req:Request,res:Response,next:NextFunction)=>{
    try{
        const {id}=req.params;
        const product=await productRepo.findOne({
            where:{id:id as string},
            relations:['sub_category']
        });
        if(!product)
        {
            return res.status(404).json({error:"Product not found"})
        }
        res.status(200).json(product)
    }
    catch(error:any)
    {
        next(error)
    }
}
export const createProduct=async(req:Request,res:Response,next:NextFunction)=>{
    try{
        const {name,description,price,stock,image_url,subCategory}=req.body;
        const subCategoryData=await subCategoryRepo.findOneBy({name:subCategory});
        if(!subCategoryData)
        {
            return res.status(404).json({error:"Subcategory not found"})
        }
        const product=productRepo.create({
            name,
            description,
            price:Number(price),
            stock:Number(stock),
            
            image_url: req.file ? `/uploads/${req.file.filename}` : "",
            sub_category:subCategoryData
        })
        await productRepo.save(product);
        res.status(200).json({product})
    }
    catch(error:any)
    {
       next(error)
    }
}
export const updateProduct=async(req:Request,res:Response,next:NextFunction)=>{
    const {id}=req.params;
    try{
        const product=await productRepo.findOneBy({id:id as string})
        if(!product)
        {
            return res.status(404).json({error:"Product not found"})
        }
        productRepo.merge(product,req.body);
        const result=await productRepo.save(product);
        res.status(200).json(result);
    }
    catch(error:any)
    {
       next(error)
    }
}
export const deleteProduct=async(req:Request,res:Response,next:NextFunction)=>{
    const {id}=req.params;
    try{
        const product=await productRepo.findOneBy({id:id as string})
        if(!product)
        {
            res.status(404).json({error:"Product not found"})
        }
        await productRepo.delete(id);
        res.status(200).json({message:"Product deleted successfully"})
    }
    catch(error:any)
    {
        next(error)
    }
}
