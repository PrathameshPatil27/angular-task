import { NextFunction, Request, Response } from "express";
import { AppDataSource } from "../data-source";
import bcrypt from "bcrypt"
import crypto from 'crypto'
import { sessionStore } from "../store/sessionStore";
import jwt from "jsonwebtoken";
import { decode } from "punycode";
import { error } from "console";
import { email, json } from "zod";
const userRepository = AppDataSource.getRepository("User");
const JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET) throw new Error("JWT_SECRET is missing in .env");
export const register = async (req: Request, res: Response,next:NextFunction) => {
    try {
        const { email, username, password, address } = req.body;
        const exists = await userRepository.findOneBy({ email });
        if (exists) {
            return res.status(400).json({ error: "Email already exists" })
        }
        const password_hash = await bcrypt.hash(password, 10);
        const user = userRepository.create({ email, username, password_hash, address });
        await userRepository.save(user);

        res.status(201).json({ Message: "Registration Successful" })

    }
    catch (e) {
       next(e)
    }
};
export const login = async (req: Request, res: Response,next:NextFunction) => {
    try {
        const { email, password } = req.body;
        const user = await userRepository.findOneBy({ email });
        if (!user || !(await bcrypt.compare(password, user.password_hash))) {
            return res.status(401).json({ error: "Invalid Credentials" })
        }
        if (user.is_locked) {
            return res.status(403).json({ error: "Account is locked" })
        }
        
        const token = jwt.sign(
            {
                id: user.id,
                role: user.role
            },
            JWT_SECRET,
            { expiresIn: "24h" }
        )

        sessionStore.set(token, { id: user.id, role: user.role });

        res.cookie('session_token', token, {
            httpOnly: true,
            secure: process.env.NODE_ENV === 'production',
            sameSite: 'strict',
            maxAge: 24 * 60 * 60 * 1000

        })
        res.json({ message: "Login Successful", role: user.role })
    }
    catch (e: any) {
       next(e)
    }
    console.log(sessionStore)
}

export const forgotPassword = async (req: Request, res: Response) => {

    const { email } = req.body;
    const user = await userRepository.findOneBy({ email });
    if (user) {
        const code = Math.floor(100000 + Math.random() * 90000).toString();
        user.reset_password_token = code;

        user.reset_password_expires = new Date(Date.now() + 15 * 60 * 1000);
        await userRepository.save(user);
        console.log(`Reset code for  ${email} is ${code}`)
        return res.json({ message: "Code generated", mock_display_code: code })
    }
    res.json({ message: "If email exists,code generated" });
}

export const resetPassword = async (req: Request, res: Response) => {
    const { token, newPassword } = req.body;
    const user = await userRepository.findOneBy({ reset_password_token: token })
    if (!user || !user.reset_password_expires || user.reset_password_expires < new Date()) {
        return res.status(400).json({ error: "Invalid or Expired Code" })
    }
    user.password_hash = await bcrypt.hash(newPassword, 10);
    user.reset_password_expires = null;
    await userRepository.save(user);
    res.json({ message: "Password reset successful" })
};

export const logout = (req: Request, res: Response) => {
    const token = req.cookies.session_token;
    if (token) {
        sessionStore.delete(token);
    }
    res.clearCookie("session_token", {
        httpOnly: true,
        secure: process.env.NODE_ENV === 'production',
        sameSite: 'strict',
        path: '/'
    })
    res.json({ message: "Logged Out" })
    console.log(sessionStore)
}
export const getMe = async (req: Request, res: Response) => {
    const token = req.cookies.session_token;
    if (!token) {
        return res.status(401).json({ message: "No session found" })
    }
    const userData = sessionStore.get(token) as any;
    if (!userData) {
        return res.status(401).json({ message: "Invalid or expired token" })
    }
    console.log("Current Token", token)
    console.log("ZFOund User Data", userData)
    res.status(200).json({

        role: userData.role,

    })

}
export const getUserProfile = async (req: Request, res: Response,next:NextFunction) => {
    try {
        const token = req.cookies.session_token;
        const sessionUser = sessionStore.get(token);
        if (!sessionUser) {
            return res.status(400).json({ error: "session invalid or expired" })
        }
        const user = await userRepository.findOneBy({ id: sessionUser.id })
        if (!user) {
            return res.status(404).json({ error: "user record not found in DB" })
        }
        const userData = {
            username: user.username,
            email: user.email,
            address: user.address,
            role:user.role
        }
        return res.status(200).json(userData);
    }
    catch (error: any) {
        next(error)
    }

}
export const updateProfile = async (req: Request, res: Response,next:NextFunction) => {
    try {
        const token = req.cookies.session_token;
        const sessionUser = sessionStore.get(token);
        if (!sessionUser) {
            return res.status(401).json({ error: "Session not found" })
        }
        const user = await userRepository.findOneBy({ id: sessionUser.id })
        if (!user) {
            return res.status(404).json({ error: "User not found" })
        }
        const { username, email, address } = req.body;
        if (username) {
            user.username = username;
        }
        if (email) {
            user.email = email
        }
        if (address) {
            user.address = address
        }
        await userRepository.save(user);
        const userData = {
            name: user.username,
            email: user.email,
            address: user.address

        }
        return res.status(200).json({ message: "Profile Updated!", user: userData })
    }
    catch(error:any)
    {
        next(error)
    }
}
