"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Migrations1775884692418 = void 0;
class Migrations1775884692418 {
    constructor() {
        this.name = 'Migrations1775884692418';
    }
    async up(queryRunner) {
        await queryRunner.query(`CREATE TABLE "user" ("id" varchar PRIMARY KEY NOT NULL, "email" varchar NOT NULL, "username" varchar, "password_hash" varchar NOT NULL, "role" varchar NOT NULL DEFAULT ('customer'), "is_locked" boolean NOT NULL DEFAULT (0), "address" varchar, "reset_password_token" varchar, "reset_password_expires" datetime, "created_at" datetime NOT NULL DEFAULT (datetime('now')), "updated_at" datetime NOT NULL DEFAULT (datetime('now')), CONSTRAINT "UQ_e12875dfb3b1d92d7d7c5377e22" UNIQUE ("email"))`);
        await queryRunner.query(`CREATE TABLE "products" ("id" varchar PRIMARY KEY NOT NULL, "name" varchar NOT NULL, "description" text NOT NULL, "price" decimal(10,2) NOT NULL, "image_url" varchar, "stock" integer NOT NULL DEFAULT (0), "created_at" datetime NOT NULL DEFAULT (datetime('now')), "updated_at" datetime NOT NULL DEFAULT (datetime('now')), "subCategoryId" varchar NOT NULL)`);
        await queryRunner.query(`CREATE TABLE "sub_categories" ("id" varchar PRIMARY KEY NOT NULL, "name" varchar NOT NULL, "categoryId" varchar NOT NULL)`);
        await queryRunner.query(`CREATE TABLE "categories" ("id" varchar PRIMARY KEY NOT NULL, "name" varchar NOT NULL, "typeId" varchar NOT NULL)`);
        await queryRunner.query(`CREATE TABLE "types" ("id" varchar PRIMARY KEY NOT NULL, "name" varchar NOT NULL, CONSTRAINT "UQ_fa170fda66d232af69b7f880c9e" UNIQUE ("name"))`);
        await queryRunner.query(`CREATE TABLE "cart_items" ("id" varchar PRIMARY KEY NOT NULL, "quantity" integer NOT NULL DEFAULT (1), "userId" varchar NOT NULL, "productId" varchar NOT NULL)`);
        await queryRunner.query(`CREATE TABLE "order_items" ("id" varchar PRIMARY KEY NOT NULL, "quantity" integer NOT NULL, "price_at_purchase" integer NOT NULL, "orderId" varchar NOT NULL, "productId" varchar NOT NULL)`);
        await queryRunner.query(`CREATE TABLE "orders" ("id" varchar PRIMARY KEY NOT NULL, "total_amount" integer NOT NULL, "status" varchar NOT NULL DEFAULT ('pending'), "payment_method" varchar, "created_at" datetime NOT NULL DEFAULT (datetime('now')), "userId" varchar NOT NULL)`);
        await queryRunner.query(`CREATE TABLE "temporary_products" ("id" varchar PRIMARY KEY NOT NULL, "name" varchar NOT NULL, "description" text NOT NULL, "price" decimal(10,2) NOT NULL, "image_url" varchar, "stock" integer NOT NULL DEFAULT (0), "created_at" datetime NOT NULL DEFAULT (datetime('now')), "updated_at" datetime NOT NULL DEFAULT (datetime('now')), "subCategoryId" varchar NOT NULL, CONSTRAINT "FK_ad42985fb27aa9016b16ee740ec" FOREIGN KEY ("subCategoryId") REFERENCES "sub_categories" ("id") ON DELETE RESTRICT ON UPDATE NO ACTION)`);
        await queryRunner.query(`INSERT INTO "temporary_products"("id", "name", "description", "price", "image_url", "stock", "created_at", "updated_at", "subCategoryId") SELECT "id", "name", "description", "price", "image_url", "stock", "created_at", "updated_at", "subCategoryId" FROM "products"`);
        await queryRunner.query(`DROP TABLE "products"`);
        await queryRunner.query(`ALTER TABLE "temporary_products" RENAME TO "products"`);
        await queryRunner.query(`CREATE TABLE "temporary_sub_categories" ("id" varchar PRIMARY KEY NOT NULL, "name" varchar NOT NULL, "categoryId" varchar NOT NULL, CONSTRAINT "FK_dfa3adf1b46e582626b295d0257" FOREIGN KEY ("categoryId") REFERENCES "categories" ("id") ON DELETE CASCADE ON UPDATE NO ACTION)`);
        await queryRunner.query(`INSERT INTO "temporary_sub_categories"("id", "name", "categoryId") SELECT "id", "name", "categoryId" FROM "sub_categories"`);
        await queryRunner.query(`DROP TABLE "sub_categories"`);
        await queryRunner.query(`ALTER TABLE "temporary_sub_categories" RENAME TO "sub_categories"`);
        await queryRunner.query(`CREATE TABLE "temporary_categories" ("id" varchar PRIMARY KEY NOT NULL, "name" varchar NOT NULL, "typeId" varchar NOT NULL, CONSTRAINT "FK_d55ba160d1a55bc93221dbac150" FOREIGN KEY ("typeId") REFERENCES "types" ("id") ON DELETE CASCADE ON UPDATE NO ACTION)`);
        await queryRunner.query(`INSERT INTO "temporary_categories"("id", "name", "typeId") SELECT "id", "name", "typeId" FROM "categories"`);
        await queryRunner.query(`DROP TABLE "categories"`);
        await queryRunner.query(`ALTER TABLE "temporary_categories" RENAME TO "categories"`);
        await queryRunner.query(`CREATE TABLE "temporary_cart_items" ("id" varchar PRIMARY KEY NOT NULL, "quantity" integer NOT NULL DEFAULT (1), "userId" varchar NOT NULL, "productId" varchar NOT NULL, CONSTRAINT "FK_84e765378a5f03ad9900df3a9ba" FOREIGN KEY ("userId") REFERENCES "user" ("id") ON DELETE CASCADE ON UPDATE NO ACTION, CONSTRAINT "FK_72679d98b31c737937b8932ebe6" FOREIGN KEY ("productId") REFERENCES "products" ("id") ON DELETE CASCADE ON UPDATE NO ACTION)`);
        await queryRunner.query(`INSERT INTO "temporary_cart_items"("id", "quantity", "userId", "productId") SELECT "id", "quantity", "userId", "productId" FROM "cart_items"`);
        await queryRunner.query(`DROP TABLE "cart_items"`);
        await queryRunner.query(`ALTER TABLE "temporary_cart_items" RENAME TO "cart_items"`);
        await queryRunner.query(`CREATE TABLE "temporary_order_items" ("id" varchar PRIMARY KEY NOT NULL, "quantity" integer NOT NULL, "price_at_purchase" integer NOT NULL, "orderId" varchar NOT NULL, "productId" varchar NOT NULL, CONSTRAINT "FK_f1d359a55923bb45b057fbdab0d" FOREIGN KEY ("orderId") REFERENCES "orders" ("id") ON DELETE CASCADE ON UPDATE NO ACTION, CONSTRAINT "FK_cdb99c05982d5191ac8465ac010" FOREIGN KEY ("productId") REFERENCES "products" ("id") ON DELETE RESTRICT ON UPDATE NO ACTION)`);
        await queryRunner.query(`INSERT INTO "temporary_order_items"("id", "quantity", "price_at_purchase", "orderId", "productId") SELECT "id", "quantity", "price_at_purchase", "orderId", "productId" FROM "order_items"`);
        await queryRunner.query(`DROP TABLE "order_items"`);
        await queryRunner.query(`ALTER TABLE "temporary_order_items" RENAME TO "order_items"`);
        await queryRunner.query(`CREATE TABLE "temporary_orders" ("id" varchar PRIMARY KEY NOT NULL, "total_amount" integer NOT NULL, "status" varchar NOT NULL DEFAULT ('pending'), "payment_method" varchar, "created_at" datetime NOT NULL DEFAULT (datetime('now')), "userId" varchar NOT NULL, CONSTRAINT "FK_151b79a83ba240b0cb31b2302d1" FOREIGN KEY ("userId") REFERENCES "user" ("id") ON DELETE RESTRICT ON UPDATE NO ACTION)`);
        await queryRunner.query(`INSERT INTO "temporary_orders"("id", "total_amount", "status", "payment_method", "created_at", "userId") SELECT "id", "total_amount", "status", "payment_method", "created_at", "userId" FROM "orders"`);
        await queryRunner.query(`DROP TABLE "orders"`);
        await queryRunner.query(`ALTER TABLE "temporary_orders" RENAME TO "orders"`);
    }
    async down(queryRunner) {
        await queryRunner.query(`ALTER TABLE "orders" RENAME TO "temporary_orders"`);
        await queryRunner.query(`CREATE TABLE "orders" ("id" varchar PRIMARY KEY NOT NULL, "total_amount" integer NOT NULL, "status" varchar NOT NULL DEFAULT ('pending'), "payment_method" varchar, "created_at" datetime NOT NULL DEFAULT (datetime('now')), "userId" varchar NOT NULL)`);
        await queryRunner.query(`INSERT INTO "orders"("id", "total_amount", "status", "payment_method", "created_at", "userId") SELECT "id", "total_amount", "status", "payment_method", "created_at", "userId" FROM "temporary_orders"`);
        await queryRunner.query(`DROP TABLE "temporary_orders"`);
        await queryRunner.query(`ALTER TABLE "order_items" RENAME TO "temporary_order_items"`);
        await queryRunner.query(`CREATE TABLE "order_items" ("id" varchar PRIMARY KEY NOT NULL, "quantity" integer NOT NULL, "price_at_purchase" integer NOT NULL, "orderId" varchar NOT NULL, "productId" varchar NOT NULL)`);
        await queryRunner.query(`INSERT INTO "order_items"("id", "quantity", "price_at_purchase", "orderId", "productId") SELECT "id", "quantity", "price_at_purchase", "orderId", "productId" FROM "temporary_order_items"`);
        await queryRunner.query(`DROP TABLE "temporary_order_items"`);
        await queryRunner.query(`ALTER TABLE "cart_items" RENAME TO "temporary_cart_items"`);
        await queryRunner.query(`CREATE TABLE "cart_items" ("id" varchar PRIMARY KEY NOT NULL, "quantity" integer NOT NULL DEFAULT (1), "userId" varchar NOT NULL, "productId" varchar NOT NULL)`);
        await queryRunner.query(`INSERT INTO "cart_items"("id", "quantity", "userId", "productId") SELECT "id", "quantity", "userId", "productId" FROM "temporary_cart_items"`);
        await queryRunner.query(`DROP TABLE "temporary_cart_items"`);
        await queryRunner.query(`ALTER TABLE "categories" RENAME TO "temporary_categories"`);
        await queryRunner.query(`CREATE TABLE "categories" ("id" varchar PRIMARY KEY NOT NULL, "name" varchar NOT NULL, "typeId" varchar NOT NULL)`);
        await queryRunner.query(`INSERT INTO "categories"("id", "name", "typeId") SELECT "id", "name", "typeId" FROM "temporary_categories"`);
        await queryRunner.query(`DROP TABLE "temporary_categories"`);
        await queryRunner.query(`ALTER TABLE "sub_categories" RENAME TO "temporary_sub_categories"`);
        await queryRunner.query(`CREATE TABLE "sub_categories" ("id" varchar PRIMARY KEY NOT NULL, "name" varchar NOT NULL, "categoryId" varchar NOT NULL)`);
        await queryRunner.query(`INSERT INTO "sub_categories"("id", "name", "categoryId") SELECT "id", "name", "categoryId" FROM "temporary_sub_categories"`);
        await queryRunner.query(`DROP TABLE "temporary_sub_categories"`);
        await queryRunner.query(`ALTER TABLE "products" RENAME TO "temporary_products"`);
        await queryRunner.query(`CREATE TABLE "products" ("id" varchar PRIMARY KEY NOT NULL, "name" varchar NOT NULL, "description" text NOT NULL, "price" decimal(10,2) NOT NULL, "image_url" varchar, "stock" integer NOT NULL DEFAULT (0), "created_at" datetime NOT NULL DEFAULT (datetime('now')), "updated_at" datetime NOT NULL DEFAULT (datetime('now')), "subCategoryId" varchar NOT NULL)`);
        await queryRunner.query(`INSERT INTO "products"("id", "name", "description", "price", "image_url", "stock", "created_at", "updated_at", "subCategoryId") SELECT "id", "name", "description", "price", "image_url", "stock", "created_at", "updated_at", "subCategoryId" FROM "temporary_products"`);
        await queryRunner.query(`DROP TABLE "temporary_products"`);
        await queryRunner.query(`DROP TABLE "orders"`);
        await queryRunner.query(`DROP TABLE "order_items"`);
        await queryRunner.query(`DROP TABLE "cart_items"`);
        await queryRunner.query(`DROP TABLE "types"`);
        await queryRunner.query(`DROP TABLE "categories"`);
        await queryRunner.query(`DROP TABLE "sub_categories"`);
        await queryRunner.query(`DROP TABLE "products"`);
        await queryRunner.query(`DROP TABLE "user"`);
    }
}
exports.Migrations1775884692418 = Migrations1775884692418;
