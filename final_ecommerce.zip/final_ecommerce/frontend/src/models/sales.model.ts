export interface SalesItem{
    id:string;
    quantity:number;
    price_at_purchase:number;
    product:{
        name:string,
        image?:string
    };
    order:{
        id:string,
        status:string;
        created_at:string;
        user:{
            username:string;
            email:string
        }
    }
}