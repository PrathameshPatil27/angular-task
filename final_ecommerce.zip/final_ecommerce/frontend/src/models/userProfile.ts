export interface userProfile{
    username:string,
    email:string,
    address:string

}