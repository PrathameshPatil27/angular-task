export interface PaginatedProducts{
    products:any[];
    total:number;
    totalPages:number;
    currentPage:number;
}