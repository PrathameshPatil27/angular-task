export interface userInfo{
    id:string;
    username:string;
    email:string;
    role:string;
    is_locked:boolean;
    created_at:string;
}