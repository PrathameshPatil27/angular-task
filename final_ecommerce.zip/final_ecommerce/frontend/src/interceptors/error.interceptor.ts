import { HttpErrorResponse, HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { Router } from '@angular/router';
import { catchError, throwError } from 'rxjs';

export const errorInterceptor: HttpInterceptorFn = (req, next) => {
  const router=inject(Router);
  return next(req).pipe(
    catchError((error:HttpErrorResponse)=>{
      let errorMessage="An unexpected error occured";
      if(error.status!==0)
      {
        errorMessage=error.error?.message||"Server Error"
      }
      else
      {
        errorMessage="Can not connect to server"
      }
      if(error.status===401)
      {
        router.navigate(['/login'])
      }
      alert(errorMessage)
      return throwError(()=>new Error(errorMessage))
    })
  )
};
