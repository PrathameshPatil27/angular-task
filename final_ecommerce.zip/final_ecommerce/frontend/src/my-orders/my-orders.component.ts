import { Component, inject, OnDestroy, OnInit } from '@angular/core';
import { OrdersService } from '../shared/orders.service';
import { Router } from '@angular/router';
import { DatePipe, NgFor, NgIf } from '@angular/common';
import { Subject, takeUntil } from 'rxjs';

@Component({
  selector: 'app-my-orders',
  imports: [DatePipe,NgIf,NgFor],
  templateUrl: './my-orders.component.html',
  styleUrl: './my-orders.component.css'
})
export class MyOrdersComponent implements OnInit,OnDestroy{
  private destroy$=new Subject<void>()
  orders:any=null;
  isLoading:boolean=true;
  orderService=inject(OrdersService)
  router=inject(Router)
  ngOnInit(): void {
    return this.loadMyOrders()
  }
  loadMyOrders()
  {
    this.orderService.getOrderHistory().pipe(takeUntil(this.destroy$)).subscribe({
      next:(data)=>{
        this.orders=data.orders
        this.isLoading=false
      },
      error:(err)=>{
        console.error("Error fetching orders")
        this.isLoading=false
      }
    })
  }
  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete()
  }
}
