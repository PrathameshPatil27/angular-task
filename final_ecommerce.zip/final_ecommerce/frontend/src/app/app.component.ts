import { Component, inject, ViewChild } from '@angular/core';
import { RouterOutlet, RouterLinkWithHref, Router } from '@angular/router';
import { AuthService } from '../auth/auth.service';
import { AsyncPipe, NgIf } from '@angular/common';
import { OnInit } from '@angular/core';
import { map } from 'rxjs';
import { ProfileComponent } from '../profile/profile.component';
@Component({
  selector: 'app-root',
  imports: [RouterOutlet, RouterLinkWithHref, NgIf, AsyncPipe],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent implements OnInit{
 
  authService=inject(AuthService)
  router=inject(Router)
  isLoggedIn$=this.authService.isLoggedIn$;
  isAdmin$=this.authService.userRole$.pipe(
    map(role=>role==="admin")
  )
  ngOnInit(){
    this.authService.checkSession().subscribe()
  }
   @ViewChild('profileComp') profileComp!: ProfileComponent;

  openProfile() {
    this.profileComp.openSlider();
  }

  // get isLoggedIn(): boolean {
  //   return this.authService.isLoggedInValue;
  // }
  // get isAdmin():boolean{
  //   return this.authService.isAdmin;
  // }
  onLogout()
  {
    this.authService.logout().subscribe({
      next:()=>{
        console.log("logged out")
        this.router.navigate(['/login'])
      },
      error:(err)=>{
        alert("Logout Failed")
      }
    })
  }
}
