import { Routes } from '@angular/router';
import { LoginComponent } from '../auth/login/login.component';
import { RegisterComponent } from '../auth/register/register.component';
import { ProductListComponent } from '../product-list/product-list.component';
import { ForgotPasswordComponent } from '../auth/forgot-password/forgot-password.component';
import { ResetPasswordComponent } from '../auth/reset-password/reset-password.component';
import { CartComponent } from '../cart/cart.component';
import { MyOrdersComponent } from '../my-orders/my-orders.component';
import { OrderDetailsComponent } from '../order-details/order-details.component';
import { ManagetaxonomyComponent } from '../managetaxonomy/managetaxonomy.component';
import { ManageProductsComponent } from '../manage-products/manage-products.component';
import { ManageOrdersComponent } from '../manage-orders/manage-orders.component';
import { ManageUsersComponent } from '../manage-users/manage-users.component';
import { ProfileComponent } from '../profile/profile.component';
import { adminGuard } from '../guards/admin.guard';



export const routes: Routes = [
    {
        path:'login',
        component:LoginComponent,
    },
    {
        path:'register',
        component:RegisterComponent
    },
    {
        path:'products',
        component:ProductListComponent
    },
    {
        path:'forgot-password',
        component:ForgotPasswordComponent
    },
    {
        path:'reset-password',
        component:ResetPasswordComponent
    },
    {
        path:'cart',
        component:CartComponent
    },
    {
        path:'my-orders',
        component:MyOrdersComponent
    },
    {
        path:'order-details/:id',
        component:OrderDetailsComponent
    },
    {
        path:'manage-taxonomy',
        component:ManagetaxonomyComponent,
        canActivate:[adminGuard]
    },
    {
        path:'manage-products',
        component:ManageProductsComponent,
        canActivate:[adminGuard]
    },
    {
        path:'sales-data',
        component:ManageOrdersComponent,
        canActivate:[adminGuard]
    },
    {
        path:'manage-users',
        component:ManageUsersComponent,
        canActivate:[adminGuard]
    },
    {
        path:'profile',
        component:ProfileComponent
    },
    {
        path:'',
        redirectTo:'products',
        pathMatch:'full'
    },
    
    {
        path:'**',
        redirectTo:'login'
    }
];
