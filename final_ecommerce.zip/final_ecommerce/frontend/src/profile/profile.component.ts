import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Subject, takeUntil } from 'rxjs';
import { userProfile } from '../models/userProfile';
import { AuthService } from '../auth/auth.service';
import { NgClass, NgIf } from '@angular/common';

@Component({
  selector: 'app-profile',
  standalone: true,
  imports: [NgClass,NgIf,ReactiveFormsModule],
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit, OnDestroy {
  private destroy$ = new Subject<void>();
  user: userProfile = { username: "", email: "", address: "" };
  profileForm!: FormGroup;
  isEditMode = false;
  message = "";
  isError = false;
   isOpen = false;

  openSlider() {
    this.isOpen = true;
  }

  closeSlider() {
    this.isOpen = false;
  }


  constructor(private authService: AuthService, private fb: FormBuilder) {}

  ngOnInit(): void {
    this.loadProfile();
  }

  loadProfile() {
    this.authService.getUserProfile().pipe(takeUntil(this.destroy$)).subscribe({
      next: (data) => {
        this.user = { ...data };
        this.initForm();
      },
      error: (err) => {
        console.error("Error loading Profile", err);
      }
    });
  }

  initForm() {
    this.profileForm = this.fb.group({
      username: [this.user.username, Validators.required],
      email: [this.user.email, [Validators.required, Validators.email]],
      address: [this.user.address]
    });
  }

  saveProfile() {
    if (this.profileForm.valid) {
      const updatedUser: userProfile = this.profileForm.value;
      this.authService.editUserProfile(updatedUser).pipe(takeUntil(this.destroy$)).subscribe({
        next: () => {
          this.user = { ...updatedUser };
          this.initForm();
          this.isEditMode = false;
          this.showStatus('Profile Updated successfully', false);
        },
        error: (err) => {
          console.log("Update failed", err);
          this.showStatus("Update failed please try again", true);
        }
      });
    }
  }

  toggleEdit() {
    if (!this.isEditMode) {
      this.isEditMode = true;
      this.initForm();
    } else {
      this.isEditMode = false;
    }
    this.message = "";
  }

  private showStatus(msg: string, error: boolean) {
    this.message = msg;
    this.isError = error;
    setTimeout(() => this.message = '', 3000);
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }
}