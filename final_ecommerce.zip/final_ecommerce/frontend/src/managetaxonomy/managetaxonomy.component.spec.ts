import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ManagetaxonomyComponent } from './managetaxonomy.component';

describe('ManagetaxonomyComponent', () => {
  let component: ManagetaxonomyComponent;
  let fixture: ComponentFixture<ManagetaxonomyComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ManagetaxonomyComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ManagetaxonomyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
