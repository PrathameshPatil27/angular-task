import { Component, inject, OnDestroy, OnInit } from '@angular/core';
import { AdminService } from '../shared/admin.service';
import { NgFor, NgIf } from '@angular/common';
import { Subject, takeUntil } from 'rxjs';

@Component({
  selector: 'app-managetaxonomy',
  imports: [NgFor],
  templateUrl: './managetaxonomy.component.html',
  styleUrl: './managetaxonomy.component.css'
})
export class ManagetaxonomyComponent implements OnInit,OnDestroy{
  adminService=inject(AdminService)
  allTypes:any[]=[];
  allCategories:any[]=[];
  allSubcategories:any[]=[];
  private destroy$=new Subject<void>()
  ngOnInit(): void {
    this.loadData();
  }
  loadData()
  {
    this.adminService.getTypes().pipe(takeUntil(this.destroy$)).subscribe({
      next:(data)=>{
        this.allTypes=data
      },
      error:(err)=>{
        console.error("Unable to fetch types",err)
      }
    })
    this.adminService.getCategories().pipe(takeUntil(this.destroy$)).subscribe({
      next:(data)=>{
        this.allCategories=data
      },
      error:(err)=>{
        console.log("Unable to fetch categories",err)
      }
    })
    this.adminService.getSubcategories().pipe(takeUntil(this.destroy$)).subscribe({
      next:(data)=>{
        this.allSubcategories=data
      },
      error:(err)=>{
        console.log("Unable to fetch subcategories",err)
      }
    })
  }
  addType(name:string){
    this.adminService.addType(name).pipe(takeUntil(this.destroy$)).subscribe({
      next:(res)=>{
        this.loadData()
        console.log(res)
      },
      error:(err)=>{
        console.log(err.message)
      }
    })
  }
  addCategory(name:string,typeId:string){
    this.adminService.addCategory(name,typeId).pipe(takeUntil(this.destroy$)).subscribe({
      next:(res)=>{
        this.loadData();
        console.log(res)
      },
      error:(err)=>{
        console.log(err.message)
      }
    })
  }
  addSubcategory(name:string,categoryId:string){
    this.adminService.addSubcategory(name,categoryId).pipe(takeUntil(this.destroy$)).subscribe({
      next:(res)=>{
        this.loadData();
        console.log(res)
      },
      error:(err)=>{
        console.log(err.message)
      }
    })
  }
  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }
}
