import { Component, OnDestroy } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ɵInternalFormsSharedModule, ReactiveFormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../auth.service';
import { Subject, takeUntil } from 'rxjs';

@Component({
  selector: 'app-register',
  imports: [ɵInternalFormsSharedModule, ReactiveFormsModule, RouterLink],
  templateUrl: './register.component.html',
  styleUrl: './register.component.css'
})
export class RegisterComponent implements OnDestroy{
  registerForm: FormGroup
  private destroy$=new Subject<void>();
  constructor(private fb: FormBuilder, private router: Router, private auth: AuthService) {
    this.registerForm = this.fb.group({
      username: ['', [Validators.required]],
      email:['',[Validators.required,Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]]
    })

  }
  onRegister()
  {
    if(this.registerForm.valid)
    {
      this.auth.register(this.registerForm.value).pipe(takeUntil(this.destroy$)).subscribe({
        next:(res)=>{
          alert("Registration successful")
          this.router.navigate(['/login'])
        },
        error:(err)=>{
          alert(err.error.error||'Registration failed')
        }
      })
    }
  }
  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }
}
