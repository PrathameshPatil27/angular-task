import { HttpClient } from '@angular/common/http';

import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, tap } from 'rxjs';
import { userProfile } from '../models/userProfile';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private API_URL = "http://localhost:3000/api/auth"
  private loggedInStatus = new BehaviorSubject<boolean>(false);
  isLoggedIn$ = this.loggedInStatus.asObservable()
  private userRole = new BehaviorSubject<string | null>(null);
  userRole$ = this.userRole.asObservable();
  constructor(private http: HttpClient) { }
  login(credentials: any): Observable<any> {
    return this.http.post(`${this.API_URL}/login`, credentials).pipe(
      tap((res: any) => {
        this.loggedInStatus.next(true);
        this.userRole.next(res.role)
      })
    )
  }
  register(userData: any): Observable<any> {
    return this.http.post(`${this.API_URL}/register`, userData)
  }
  logout(): Observable<any> {
    return this.http.post(`${this.API_URL}/logout`, {}).pipe(
      tap(() => {
        this.loggedInStatus.next(false)
      })
    )
  }
  get isLoggedInValue(): boolean {
    return this.loggedInStatus.value;
  }
  get isAdmin(): boolean {
    return this.userRole.value === 'admin'
  }
  checkSession(): Observable<any> {
    return this.http.get(`${this.API_URL}/me`,{withCredentials:true}).pipe(
      tap({
        next:(user:any)=>{
          this.loggedInStatus.next(true)
          this.userRole.next(user.role)
        },
        error:()=>{
          this.loggedInStatus.next(false)
        }
      })
    )
  }
  forgotPassword(email:string):Observable<any>{
    return this.http.post(`${this.API_URL}/forgot-password`,{email})
  }
  resetPassword(data:any):Observable<any>{
    return this.http.post(`${this.API_URL}/reset-password`,data)
  }
  getUserProfile():Observable<userProfile>{
    return this.http.get<userProfile>(`${this.API_URL}/user-profile`,{withCredentials:true})
  }
  editUserProfile(data:userProfile):Observable<userProfile>{
    return this.http.put<userProfile>(`${this.API_URL}/update-profile`,data,{withCredentials:true})
  }
}
