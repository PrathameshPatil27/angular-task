import { Component, inject, OnDestroy } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { AuthService } from '../auth.service';
import { Router, RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';
import { Subject, take, takeUntil } from 'rxjs';

@Component({
  selector: 'app-login',
  imports: [RouterLink,ReactiveFormsModule,CommonModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent implements OnDestroy{
  loginForm:FormGroup;
  private destroy$=new Subject<void>();
  constructor(private fb:FormBuilder,private auth:AuthService,private router:Router)
  {
    this.loginForm=this.fb.group({
      email:['',[Validators.required,Validators.email]],
      password:['',Validators.required]
      
    })
    
  }
  onLogin()
  {
    if(this.loginForm.valid)
    {
      this.auth.login(this.loginForm.value).pipe(takeUntil(this.destroy$)).subscribe({
        next:(res)=>{
          // alert("Login Successful")
          this.router.navigate(['/products'])
        },
        error:(err)=>{
          alert(err.error.error||'Invalid Credentials')
        }
      })
    }
  }
  ngOnDestroy(): void {
    this.destroy$.next()
    this.destroy$.complete()
  }
}
