import { Component, inject, OnDestroy } from '@angular/core';
import { AuthService } from '../auth.service';
import { FormBuilder, FormGroup, Validators, ɵInternalFormsSharedModule, ReactiveFormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { Subject, takeUntil } from 'rxjs';

@Component({
  selector: 'app-forgot-password',
  imports: [ReactiveFormsModule, RouterLink],
  templateUrl: './forgot-password.component.html',
  styleUrl: './forgot-password.component.css'
})
export class ForgotPasswordComponent implements OnDestroy{
  forgotForm: FormGroup
  private destroy$=new Subject<void>();
  constructor(private auth: AuthService, private fb: FormBuilder, private router: Router) {
    this.forgotForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]]
    })
  }
  onSubmit(){
    this.auth.forgotPassword(this.forgotForm.value.email).pipe(takeUntil(this.destroy$)).subscribe({
      next:(res)=>{
        alert("Your reset code is: " + res.mock_display_code);
        this.router.navigate(["/reset-password"])
      },
      error:(err)=>{

      }
    })
  }
  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }


}
