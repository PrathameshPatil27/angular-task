"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthService = void 0;
const http_1 = require("@angular/common/http");
const core_1 = require("@angular/core");
const rxjs_1 = require("rxjs");
let AuthService = class AuthService {
    constructor(http) {
        this.http = http;
        this.API_URL = "http://localhost:3000/api/auth";
        this.loggedInStatus = new rxjs_1.BehaviorSubject(false);
        this.isLoggedIn$ = this.loggedInStatus.asObservable();
        this.userRole = new rxjs_1.BehaviorSubject(null);
        this.userRole$ = this.userRole.asObservable();
    }
    login(credentials) {
        return this.http.post(`${this.API_URL}/login`, credentials).pipe((0, rxjs_1.tap)((res) => {
            this.loggedInStatus.next(true);
            this.userRole.next(res.role);
        }));
    }
    register(userData) {
        return this.http.post(`${this.API_URL}/register`, userData);
    }
    logout() {
        return this.http.post(`${this.API_URL}/logout`, {}).pipe((0, rxjs_1.tap)(() => {
            this.loggedInStatus.next(false);
        }));
    }
    get isLoggedInValue() {
        return this.loggedInStatus.value;
    }
    get isAdmin() {
        return this.userRole.value === 'admin';
    }
    checkSession() {
        return this.http.get(`${this.API_URL}/me`, { withCredentials: true }).pipe((0, rxjs_1.tap)({
            next: (user) => {
                this.loggedInStatus.next(true);
                this.userRole.next(user.role);
            },
            error: () => {
                this.loggedInStatus.next(false);
            }
        }));
    }
    forgotPassword(email) {
        return this.http.post(`${this.API_URL}/forgot-password`, { email });
    }
    resetPassword(data) {
        return this.http.post(`${this.API_URL}/reset-password`, data);
    }
    getUserProfile() {
        return this.http.get(`${this.API_URL}/user-profile`, { withCredentials: true });
    }
    editUserProfile(data) {
        return this.http.put(`${this.API_URL}/update-profile`, data, { withCredentials: true });
    }
};
exports.AuthService = AuthService;
exports.AuthService = AuthService = __decorate([
    (0, core_1.Injectable)({
        providedIn: 'root'
    }),
    __metadata("design:paramtypes", [http_1.HttpClient])
], AuthService);
