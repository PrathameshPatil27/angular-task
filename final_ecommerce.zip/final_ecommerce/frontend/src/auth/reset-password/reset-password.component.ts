import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../auth.service';
import { Subject, takeUntil } from 'rxjs';

@Component({
  selector: 'app-reset-password',
  imports: [ReactiveFormsModule, RouterLink],
  templateUrl: './reset-password.component.html',
  styleUrl: './reset-password.component.css'
})
export class ResetPasswordComponent implements OnDestroy{
  resetForm:FormGroup;
  private destroy$=new Subject<void>();
  constructor(private router:Router,private auth:AuthService,private fb:FormBuilder)
  {
    this.resetForm=fb.group({
      token:['',[Validators.required,Validators.pattern('^[0-9]{6}$')]],
      newPassword:['',[Validators.required,Validators.minLength(6)]]
    })
  }
  onSubmit(){
    this.auth.resetPassword(this.resetForm.value).pipe(takeUntil(this.destroy$)).subscribe({
      next:()=>{
        alert("Password updated successfully");
        this.router.navigate(['/api/auth/login'])

      },
      error:(err:any)=>{
        alert(err.error.error||"Invalid or expired code")
      }
    })
  }
  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete()
  }
}
