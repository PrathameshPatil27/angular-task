import { Component, inject, OnDestroy, OnInit } from '@angular/core';
import { AdminService } from '../shared/admin.service';
import { userInfo } from '../models/userInfo.model';
import { NgClass, NgFor, NgIf } from '@angular/common';
import { Subject, takeUntil } from 'rxjs';

@Component({
  selector: 'app-manage-users',
  imports: [NgIf,NgFor,NgClass],
  templateUrl: './manage-users.component.html',
  styleUrl: './manage-users.component.css'
})
export class ManageUsersComponent implements OnInit,OnDestroy{
  private adminService=inject(AdminService);
  private destroy$=new Subject<void>()
  users:userInfo[]=[]
  ngOnInit(): void {
    this.loadAllUsers();
  }
  loadAllUsers()
  {
    this.adminService.getUsers().pipe(takeUntil(this.destroy$)).subscribe(data=>this.users=data)
  }
  onToggleLock(userId:string)
  {
    this.adminService.toggleUserLock(userId).pipe(takeUntil(this.destroy$)).subscribe(()=>{
      this.loadAllUsers()
    })
  }
  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete()
  }
}
