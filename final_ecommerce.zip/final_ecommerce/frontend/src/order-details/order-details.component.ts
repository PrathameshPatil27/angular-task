import { Component, inject, OnDestroy, OnInit } from '@angular/core';
import { OrdersService } from '../shared/orders.service';
import { ActivatedRoute, Router } from '@angular/router';
import { DatePipe, NgFor, NgIf } from '@angular/common';
import { Subject, takeUntil } from 'rxjs';

@Component({
  selector: 'app-order-details',
  imports: [NgIf,NgFor,DatePipe],
  templateUrl: './order-details.component.html',
  styleUrl: './order-details.component.css'
})
export class OrderDetailsComponent implements OnInit,OnDestroy{
  order:any=null;
  orderService=inject(OrdersService)
  router=inject(Router)
  private destroy$=new Subject<void>()
  private route=inject(ActivatedRoute)
  ngOnInit(): void {
    
    const orderId = this.route.snapshot.paramMap.get('id');
    
    if (orderId) {
      this.getOrderDetails(orderId);
    }
  }
  getOrderDetails(id:string){
    this.orderService.getOrderDetails(id).pipe(takeUntil(this.destroy$)).subscribe({
      next:(data)=>{
        this.order=data
      },
      error:(err)=>{
        console.error("Failed to fetch order details")
      }
    })
  }
  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }

}
