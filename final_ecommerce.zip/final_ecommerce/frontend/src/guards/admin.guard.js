"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.adminGuard = void 0;
const core_1 = require("@angular/core");
const router_1 = require("@angular/router");
const auth_service_1 = require("../auth/auth.service");
const rxjs_1 = require("rxjs");
const adminGuard = () => {
    const authService = (0, core_1.inject)(auth_service_1.AuthService);
    const router = (0, core_1.inject)(router_1.Router);
    return authService.getUserProfile().pipe((0, rxjs_1.map)((res) => {
        if (res && res.role == 'admin') {
            return true;
        }
        alert("Access Denied:Admins only");
        router.navigate(['/']);
        return false;
    }));
};
exports.adminGuard = adminGuard;
