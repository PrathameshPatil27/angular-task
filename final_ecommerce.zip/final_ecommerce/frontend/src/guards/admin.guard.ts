import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { AuthService } from '../auth/auth.service';
import { map } from 'rxjs';

export const adminGuard: CanActivateFn = () => {
  const authService=inject(AuthService)
  const router=inject(Router)
  return authService.getUserProfile().pipe(map((res :any)=>{
    if(res &&res.role=='admin')
    {
      return true;
    }
    alert("Access Denied:Admins only")
    router.navigate(['/'])
    return false;
  }))
};
