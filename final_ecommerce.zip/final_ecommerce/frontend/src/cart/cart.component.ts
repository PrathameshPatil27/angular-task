import { Component, inject, OnDestroy, OnInit } from '@angular/core';
import { CartService } from '../shared/cart.service';
import { NgIf,NgFor } from '@angular/common';
import { Router } from '@angular/router';
import { FormsModule } from "@angular/forms";
import { Subject, takeUntil } from 'rxjs';


@Component({
  selector: 'app-cart',
  imports: [NgIf, NgFor, FormsModule],
  templateUrl: './cart.component.html',
  styleUrl: './cart.component.css'
})
export class CartComponent implements OnInit,OnDestroy{
  cart:any=null;
  loading:boolean=true;
  cartService=inject(CartService);
  router=inject(Router)
  private destroy$=new Subject<void>();
  ngOnInit(): void {
    this.loadCartData()
  }
  loadCartData()
  {
    this.loading=true;
    this.cartService.loadFullCart().pipe(takeUntil(this.destroy$)).subscribe({
      next:(data)=>{
        this.cart=data;
        this.loading=false
      },
      error:(err)=>{
        console.log("Error in fetching cart")
        this.loading=false
      }
      
    })
  }
  updateQuantity(productId:string,change:number)
  {
      this.cartService.addToCart(productId,change).pipe(takeUntil(this.destroy$)).subscribe({
        next:()=>{
          
          this.loadCartData();
        },
        error:(err)=>{
          alert("Could not update quantity")
        }
      })
  }
  removeItem(itemID:string)
  {
    if(confirm("Do you want to remove this item from cart"))
    {
      this.cartService.removeFromCart(itemID).pipe(takeUntil(this.destroy$)).subscribe({
        next:()=>{
          this.loadCartData();
          alert("Item Removed from cart")
        },
        error:(err)=>{
          alert("Failed to remove an item from cart")
        }
      })
    }
  }
 
  calculateTotal():number{
    if(!this.cart||!this.cart.items)
    {
      return 0;
    }
    return this.cart.items.reduce((acc:number,item:any)=>{
      return acc+(item.product.price*item.quantity)
    },0)
  }
  selectedPaymentMethod="COD";
  paymentOptions=[
    {id:"COD",label:"Cash On Delivery"},
    {id:"UPI",label:"UPI or QR Code"},
    {id:"Card",label:"Credit/Debit Card"}
  ];
  checkout()
  {
    this.cartService.checkout(this.selectedPaymentMethod).pipe(takeUntil(this.destroy$)).subscribe({
      next:( res:any)=>{
        alert(res.message);
        this.cart={itms:[],total_amount:0}
        this.router.navigate(["/products"])
      },
      error:(err)=>{
        alert("Checkout Failed")
      }
    })
  }
  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }
}
