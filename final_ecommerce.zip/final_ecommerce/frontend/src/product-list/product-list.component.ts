import { Component, inject, OnDestroy, OnInit, ɵtriggerResourceLoading } from '@angular/core';
import { ProductService } from '../shared/product.service';
import { NgFor, NgIf, CommonModule } from '@angular/common';
import { CartService } from '../shared/cart.service';
import { debounce, debounceTime, distinctUntilChanged, map, Subject, Subscription, switchMap, take, takeUntil } from 'rxjs';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../auth/auth.service';
@Component({
  selector: 'app-product-list',
  imports: [NgFor, NgIf, CommonModule, FormsModule],
  templateUrl: './product-list.component.html',
  styleUrl: './product-list.component.css'
})
export class ProductListComponent implements OnInit, OnDestroy {
  private destroy$ = new Subject<void>();
  productService = inject(ProductService)
  cartService = inject(CartService)
  authService = inject(AuthService)
  private searchSubject = new Subject<string>();
  private serachSubscription?: Subscription;
  pagination: any = { total: 0, page: 1, limit: 8, totalPages: 0 };
  isAdmin$ = this.authService.userRole$.pipe(
    map(role => role === "admin")
  )

  products: any[] = [];
  allTypes: any[] = []
  allcategories: any[] = []
  allSubcategories: any[] = []
  //screen filtered list
  displayCategories: any[] = []
  displaySubcatgories: any[] = []

  selectedType: string = '';
  selectedCategories: string = '';
  selectedSubcategories: string = '';
  loading: boolean = false
  searchTerm: string = '';
  minPrice: number | null = null;
  maxPrice: number | null = null;
  isFilterVisible: boolean = false;
  selectedProduct: any = null;
  toastMessage:string|null=null;
  toastType:string='';
  openProductModal(product: any): void {
    console.log("Opening modal for product:", product);

    this.selectedProduct = product;
  }

  closeProductModal(): void {
    this.selectedProduct = null;
  }
  ngOnInit(): void {
    this.productService.getTypes().pipe(takeUntil(this.destroy$)).subscribe({
      next: (data) => {
        this.allTypes = data;
      }
    })
    this.productService.getCategories().pipe(takeUntil(this.destroy$)).subscribe({
      next: (data) => {
        this.allcategories = data
      }
    })
    this.productService.getSubCategories().pipe(takeUntil(this.destroy$)).subscribe({
      next: (data) => {
        this.allSubcategories = data
      }
    })
    this.serachSubscription = this.searchSubject.pipe(
      debounceTime(500),
      distinctUntilChanged(),
      takeUntil(this.destroy$)
    ).subscribe(() => {
      this.applyFilters();
    });
    this.applyFilters();

  }

  onSerachInput(): void {
    console.log("Typing", this.searchTerm)
    this.searchSubject.next(this.searchTerm)
  }
  loadProducts(term: string): void {
    this.loading = true
    this.productService.getAllProducts(term).pipe(takeUntil(this.destroy$)).subscribe({
      next: (data) => {
        this.products = data as any[];
        this.loading = false
      },
      error: (err: any) => {
        console.error("Could not fetch product", err.message)
      }
    })
  }
  onTypeChange(): void {
    this.selectedCategories = '';
    this.selectedSubcategories = '';
    this.displayCategories = this.allcategories.filter(c =>
      c.type?.id === this.selectedType
    );
  }
  onCategoryChange(): void {
    this.selectedSubcategories = '';
    this.displaySubcatgories = this.allSubcategories.filter((sc: any) => sc.category?.id === this.selectedCategories)
  }

  applyFilters(page: number = 1): void {
    this.loading = true;
    this.productService.getAllProducts(this.searchTerm, this.selectedSubcategories, this.selectedCategories, this.selectedType, this.minPrice, this.maxPrice, page, 8).subscribe({
      next: (res: any) => {

        this.products = res.data;
        this.pagination = res.pagination;
        this.loading = false;

      }
    });
  }
  goToPage(page: number): void {
    if (page >= 1 && page <= this.pagination.totalPages) {
      this.applyFilters(page);
    }
  }

  resetFilters(): void {
    this.searchTerm = '';
    this.selectedType = '';
    this.selectedCategories = '';
    this.selectedSubcategories = '';
    this.minPrice = 0;
    this.maxPrice = null;
    this.applyFilters();
  }
  addToCart(productId: string) {
    console.log("Adding product to cart", productId)
    this.cartService.addToCart(productId, 1).pipe(takeUntil(this.destroy$)).subscribe({
      next: (res) => {
        console.log(res)
      },
      error: (err) => {
        if(err.status===401||err.error?.error==="session invalid or expires")
        {
          this.showLoginToast('Please login to add products','error')
        }
        console.log(err)
      }
    })
  }
  // addToCart(productId: string) {
  //   this.authService.getUserProfile().subscribe({
  //     next: (user) => {
  //       if (user) {
  //         console.log("Adding product to cart", productId)
  //         this.cartService.addToCart(productId, 1).pipe(takeUntil(this.destroy$)).subscribe({
  //           next: (res) => {
  //             console.log(res)
  //           },
  //           error: (err) => {
  //             console.log(err)
  //           }
  //         })
  //       }
  //       else
  //       {
  //         this.showLoginToast();
  //       }
  //     }
  //   })
  // }
  showLoginToast(msg:string,type:string)
  {
    this.toastMessage=msg;
    this.toastType=type;
    setTimeout(()=>{
      this.toastMessage=null;
    },3000)
  
  }
  scrollToProducts() {
    const element = document.querySelector('.serach-header');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  }
  toggleFilters() {
    this.isFilterVisible = !this.isFilterVisible;
  }
  ngOnDestroy(): void {
    this.serachSubscription?.unsubscribe();
    this.destroy$.next(),
      this.destroy$.complete()
  }
}
