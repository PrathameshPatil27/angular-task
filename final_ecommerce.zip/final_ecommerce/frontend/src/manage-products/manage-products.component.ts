import { Component, inject, OnDestroy, OnInit } from '@angular/core';
import { AdminService } from '../shared/admin.service';
import { ProductService } from '../shared/product.service';
import { CommonModule, CurrencyPipe, NgFor, NgIf, SlicePipe } from '@angular/common';
import { RouterLinkActive } from "@angular/router";
import { FormsModule } from '@angular/forms';
import { Subject, takeUntil } from 'rxjs';

@Component({
  selector: 'app-manage-products',
  imports: [ SlicePipe, NgFor, NgIf,CommonModule,FormsModule],
  templateUrl: './manage-products.component.html',
  styleUrl: './manage-products.component.css'
})
export class ManageProductsComponent implements OnInit,OnDestroy{
  adminService=inject(AdminService)
  productService=inject(ProductService)
  allProducts:any[]=[]
  pagination: any = { total: 0, page: 1, limit: 8, totalPages: 0 };
  allSubcategories: any[] = [];
  loading:boolean=true
  editingProductId: string | null = null;  
  showEditModal: boolean = false;
  editForm: any = {};   
  private destroy$=new Subject<void>()
  ngOnInit(): void {
    this.loadAllProducts()
    this.loadSubcategories(); 
  }
  
  loadSubcategories() {
    this.adminService.getSubcategories().pipe(takeUntil(this.destroy$)).subscribe({
      next: (res: any) => {
        this.allSubcategories = res;
      },
      error: (err) => console.error("Could not fetch subcategories", err.message)
    });
  }

  startEdit(product: any) {
    this.editingProductId = product.id;
    this.editForm = {
      name: product.name,
      description: product.description,
      price: product.price,
      stock: product.stock,
      image_url: product.image_url,
    };
    this.showEditModal = true
  }

  cancelEdit() {
    this.showEditModal = false;
    this.editingProductId = null;
    this.editForm = {};
  }
  loadAllProducts(page: number = 1)
  {
    this.loading = true
    this.productService.getAllProducts('', '', '', '', 0, undefined,page,8).pipe(takeUntil(this.destroy$)).subscribe({
      next: (res:any) => {
        console.log("Products received from server:", res);
        this.allProducts = res.data;
        this.pagination=res.pagination
        this.loading = false
      },
      error: (err: any) => {
        console.error("Could not fetch product", err.message)
      }
    })
  }
   goToPage(page: number) {
    if (page >= 1 && page <= this.pagination.totalPages) {
      this.loadAllProducts(page);
    }
  }

addProduct(
  nameInput: HTMLInputElement,
  descInput: HTMLTextAreaElement,
  priceInput: HTMLInputElement,
  stockInput: HTMLInputElement,
  imageInput: HTMLInputElement,
  subCatInput: HTMLSelectElement
) {
  const formData = new FormData();
  formData.append("name", nameInput.value);
  formData.append("description", descInput.value);
  formData.append("price", priceInput.value);
  formData.append("stock", stockInput.value);
  formData.append("subCategory", subCatInput.value);

  if (imageInput.files && imageInput.files[0]) {
    formData.append("image", imageInput.files[0]); // must match upload.single("image")
  }

  this.adminService.addProduct(formData).pipe(takeUntil(this.destroy$)).subscribe({
    next: (res) => {
      this.loadAllProducts();
      console.log(res);
      nameInput.value = '';
      descInput.value = '';
      priceInput.value = '';
      stockInput.value = '';
      imageInput.value = '';
      subCatInput.value = '';
    },
    error: (err) => {
      console.error(err);
    }
  });
}
  deleteProduct(productId:string){
    this.adminService.deleteProduct(productId).pipe(takeUntil(this.destroy$)).subscribe({
      next:(res)=>{
        this.loadAllProducts();
        console.log(res)
      },
      error:(err)=>{
        console.error(err.message)
      }
    })
  }
  updateProduct(productId: string, productData: any) {
    this.adminService.updateProduct(productId, productData).pipe(takeUntil(this.destroy$)).subscribe({
      next: () => {
        this.cancelEdit();
        this.loadAllProducts();
      },
      error: (err: any) => console.log
      
    });
  }
  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete()
  }
}
