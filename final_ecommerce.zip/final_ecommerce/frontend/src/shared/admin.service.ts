import { HttpClient, HttpErrorResponse, HttpParams } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { observableToBeFn } from 'rxjs/internal/testing/TestScheduler';
import { SalesItem } from '../models/sales.model';
import { userInfo } from '../models/userInfo.model';
@Injectable({
  providedIn: 'root'
})
export class AdminService {
  API_URL='http://localhost:3000/api/admin'
  API_URL2='http://localhost:3000/api/products'
    http=inject(HttpClient)
    getTypes():Observable<any>{
      return this.http.get(`${this.API_URL}/types`,{withCredentials:true})
    }
    getCategories():Observable<any>{
      return this.http.get(`${this.API_URL}/categories`,{withCredentials:true})
    }
    getSubcategories():Observable<any>{
      return this.http.get(`${this.API_URL}/sub-categories`,{withCredentials:true})
    }
    addType(name:string){
      return this.http.post(`${this.API_URL}/types`,{name},{withCredentials:true})
    }
    addCategory(name:string,typeId:string){
      return this.http.post(`${this.API_URL}/categories`,{name,typeId},{withCredentials:true})
    }
    addSubcategory(name:string,categoryId:string)
    {
      return this.http.post(`${this.API_URL}/sub-categories`,{name,categoryId},{withCredentials:true})
    }
    addProduct(productData:FormData)
    {
      return this.http.post(`${this.API_URL2}`,productData,{withCredentials:true})
    }
    updateProduct(id:string,productData:FormData){
      return this.http.put(`${this.API_URL2}/${id}`,productData,{withCredentials:true})
    }
    deleteProduct(id:string){
      return this.http.delete(`${this.API_URL2}/${id}`,{withCredentials:true})
    }
    getAllSalesData():Observable<SalesItem[]>{
      return this.http.get<SalesItem[]>(`${this.API_URL}/getAllSalesData`,{withCredentials:true})
    }
    getUsers():Observable<userInfo[]>{
      return this.http.get<userInfo[]>(`${this.API_URL}/users`,{withCredentials:true})
    }
    toggleUserLock(userId:string):Observable<any>{
      return this.http.patch(`${this.API_URL}/users/${userId}`,{},{withCredentials:true})
    }
}
