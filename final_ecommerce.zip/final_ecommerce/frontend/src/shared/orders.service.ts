import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class OrdersService {
  private API_URL="http://localhost:3000/api/orders"
  http=inject(HttpClient);
  getOrderHistory():Observable<any>{
    return this.http.get(`${this.API_URL}/history`,{withCredentials:true})
  }
  getOrderDetails(orderId:string):Observable<any>{
    return this.http.get(`${this.API_URL}/${orderId}`,{withCredentials:true})
  }
}
