import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { BehaviorSubject, Observable, reduce, tap } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CartService {
  private API_URL='http://localhost:3000/api/cart'
  private cartCount=new BehaviorSubject<number>(0);
  cartCount$=this.cartCount.asObservable();
  http=inject(HttpClient)
  addToCart(productId:string,quantity:number){
    return this.http.post(`${this.API_URL}/add`,{productId,quantity},{withCredentials:true}).
    pipe(
      tap(()=>
        this.getCartCount()
      )
    )
  }
  getCartCount(){
    this.http.get<any>(`${this.API_URL}`,{
      withCredentials:true
    }).subscribe(cart=>{
      const total=cart.items?.reduce((acc:number,item:any)=>acc+item.quantity,0)||0;
      this.cartCount.next(total)
    })
  }
  loadFullCart()
  {
    return this.http.get<any>(`${this.API_URL}`,{
      withCredentials:true
    })
  }
  removeFromCart(itemId:string)
  {
    return this.http.delete(`${this.API_URL}/remove/${itemId}`,{withCredentials:true})
    .pipe(
      tap(()=>{
        this.getCartCount();
      })
    )
  }
  checkout(paymentMethod:string)
  {
    const body={payment_method:paymentMethod}
    const options={withCredentials:true}
    return this.http.post('http://localhost:3000/api/orders/checkout',body,options)
  }
}
