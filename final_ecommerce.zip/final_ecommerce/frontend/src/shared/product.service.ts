import { HttpClient, HttpParams } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  private API_URL = 'http://localhost:3000/api'
  http = inject(HttpClient)

  getAllProducts(search: string = '', subCatId: string = '', catId: string = '', typeId: string = '',minPrice?:number|null,maxPrice?:number|null,page: number = 1,
  limit: number = 8
) {
    const params = new URLSearchParams();
    if (search) params.append('search', search);
    if (subCatId) params.append('subCategoryId', subCatId);
    if (catId) params.append('categoryId', catId);
    if (typeId) params.append('typeId', typeId);
    params.append('page', page.toString());
  params.append('limit', limit.toString());

    if(Number.isFinite(minPrice)) params.append('minPrice',minPrice!.toString() )
      if(Number.isFinite(maxPrice)) params.append('maxPrice',maxPrice!.toString() )
    const queryString = params.toString();
    const finalUrl = queryString ? `${this.API_URL}/products?${queryString}` : `${this.API_URL}/products`;
    console.log("Requesting URL:", finalUrl);
    return this.http.get(finalUrl, { withCredentials: true });
  }
  getproductById(id: number): Observable<any> {
    return this.http.get<any>(`${this.API_URL}/${id}`)
  }
  getTypes(): Observable<any> {
    return this.http.get<any>(`${this.API_URL}/admin/types`, { withCredentials: true })
  }
  getCategories(): Observable<any> {
    return this.http.get<any>(`${this.API_URL}/admin/categories`, { withCredentials: true })
  }
  getSubCategories(): Observable<any> {
    return this.http.get(`${this.API_URL}/admin/sub-categories`, { withCredentials: true })
  }

}
