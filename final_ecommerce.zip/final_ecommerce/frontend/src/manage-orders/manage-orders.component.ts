import { Component, inject, OnDestroy, OnInit } from '@angular/core';
import { AdminService } from '../shared/admin.service';
import { SalesItem } from '../models/sales.model';
import { CommonModule, NgClass } from '@angular/common';
import { Subject, takeUntil } from 'rxjs';
@Component({
  selector: 'app-manage-orders',
  imports: [CommonModule,NgClass],
  templateUrl: './manage-orders.component.html',
  styleUrl: './manage-orders.component.css'
})
export class ManageOrdersComponent implements OnInit,OnDestroy{
  private adminService=inject(AdminService);
  private destroy$=new Subject<void>();
  sales:SalesItem[]=[];
  isLoading=true;
  ngOnInit():void{
    this.loadSales()
  }
  loadSales()
  {
    this.isLoading=true;
    this.adminService.getAllSalesData().pipe(takeUntil(this.destroy$)).subscribe({
      next:(data)=>{
        this.sales=data;
        this.isLoading=false;
      },
      error:(err)=>{
        console.log("Unable to load sales data",err.message)
        this.isLoading=false
      }
    })
  }
  get totalSales(): number {
  return this.sales.reduce((sum, item) => sum + item.price_at_purchase, 0);
}
  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }
}
